<div class="modal fade" id="createemp" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title  fw-bold" id="createprojectlLabel"> Add Employee</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="deadline-form" id="empform">

                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-primary" onclick="SubmitForm()">Save</button>
                <button type="button" class="btn btn-danger text-white" data-bs-dismiss="modal">Cancel</button>
            </div>
        </div>
    </div>
</div>