 <!-- Modal  Delete Folder/ File-->
 <div class="modal fade" id="deleteproject" tabindex="-1" aria-hidden="true">
     <div class="modal-dialog modal-dialog-centered modal-md modal-dialog-scrollable">
         <div class="modal-content">
             <div class="modal-header">
                 <h5 class="modal-title  fw-bold" id="deleteprojectLabel"> Delete item Permanently?</h5>
                 <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
             </div>
             <div class="modal-body justify-content-center flex-column d-flex">
                 <i class="icofont-ui-delete text-danger display-2 text-center mt-2"></i>
                 <p class="mt-4 fs-5 text-center">You can only delete this item Permanently</p>
             </div>
             <div class="modal-footer">
                 <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                 <button type="button" class="btn btn-danger color-fff">Delete</button>
             </div>
         </div>
     </div>
 </div>